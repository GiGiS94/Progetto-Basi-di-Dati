CREATE OR REPLACE TRIGGER Controllo_Presenza 
BEFORE INSERT OR UPDATE ON Presenza
FOR EACH ROW
DECLARE
Errore_Controllo EXCEPTION;
BEGIN 
IF (:NEW.Data_Presenza_Ingresso > :NEW.Data_Presenza_Uscita) THEN
RAISE Errore_Controllo;
END IF;
EXCEPTION WHEN
Errore_Controllo THEN 
RAISE_APPLICATION_ERROR (-20011,'Errore delle presenze');
END;


CREATE OR REPLACE TRIGGER Controllo_Contatti_Utente 
BEFORE INSERT OR UPDATE ON Contatti_Utente
FOR EACH ROW
DECLARE
Errore_Contatti_Utente EXCEPTION;
BEGIN
IF (:NEW.Telefono = :NEW.Telefono) THEN
RAISE Errore_Contatti_Utente;
END IF;
EXCEPTION WHEN
Errore_Contatti_Utente THEN
RAISE_APPLICATION_ERROR (-20022,'Errore nella registrazione dell Utente, telefono già presente');
END;


CREATE OR REPLACE TRIGGER Controllo_Copia 
BEFORE INSERT OR UPDATE ON Copia
FOR EACH ROW
DECLARE
Errore_Copia EXCEPTION;
BEGIN
IF (:NEW.ID_Reparto != :NEW.ID_Reparto OR :NEW.Num_Copia =:NEW.Num_Copia) THEN
RAISE Errore_Copia;
END IF;
EXCEPTION WHEN
Errore_Copia THEN
RAISE_APPLICATION_ERROR (-20033,'Errore, stessa copia presente in più di un reparto');
END;


CREATE OR REPLACE TRIGGER Verifica_Stato_Copia 
BEFORE INSERT OR UPDATE ON Copia
FOR EACH ROW
DECLARE 
Errore_Stato EXCEPTION; 
BEGIN 
IF (:NEW.Stato = 'Pessime condizioni') THEN 
RAISE Errore_Stato; 
END IF; 
EXCEPTION WHEN 
Errore_Stato THEN 
RAISE_APPLICATION_ERROR (-20044,'Errore, Libro inserito in pessime condizioni'); 
END;


CREATE OR REPLACE TRIGGER Verifica_Tipologia 
BEFORE INSERT OR UPDATE ON Libro
FOR EACH ROW
BEGIN
IF (:NEW.Anno < 1900) THEN
:NEW.Tipologia := 'Antico';
ELSE 
:NEW.Tipologia := 'Contemporaneo';
END IF;
END;


CREATE OR REPLACE TRIGGER Verifica_Turno 
BEFORE INSERT OR UPDATE ON Presenza
FOR EACH ROW
BEGIN
IF (:OLD.Data_Presenza_Ingresso != '09-06-2022 14:00:00' OR :OLD.Data_Presenza_Ingresso != '10-06-2022 14:00:00') THEN
:NEW.Tipologia_Turno := 'Mattino';
ELSE 
:NEW.Tipologia_Turno := 'Pomeriggio';
END IF;
END;