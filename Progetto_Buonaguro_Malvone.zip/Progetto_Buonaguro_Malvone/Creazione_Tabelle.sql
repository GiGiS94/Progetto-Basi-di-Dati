CREATE TABLE Autore (
	Cod_Autore char(5) primary key,
	Nome varchar (255) not null,
	Cognome varchar (255) not null,
	Data_Nascita date not null
);

CREATE TABLE Casa_Editrice (
	P_IVA char (11) primary key,
	Nome_CE varchar (255) not null,
	Sede varchar (255)
);

CREATE TABLE Collezione (
	Nome_Collezione varchar (255) primary key,
	Tipo_Collezione varchar (255) not null
);

CREATE TABLE Utente (
	Num_Tessera char (6) primary key,
	Nome varchar (255),
	Cognome varchar (255),
	Indirizzo varchar (255),
	Citta varchar (255)
);

CREATE TABLE Contatti_Utente (
	Telefono char (10) not null,
	Email varchar (255) not null,
	Num_Tessera char (6) not null,
	constraint FK_Num_TesseraZ foreign key (Num_Tessera) references Utente (Num_Tessera)
);

CREATE TABLE Reparto (
	ID_Reparto int check (ID_Reparto < 500) primary key,
	Tipo_Reparto varchar (255) not null
);

CREATE TABLE Bibliotecario (
	ID_Tesserino char (6) primary key,
	Nome varchar (255) not null,
	Cognome varchar (255) not null,
	Ruolo varchar (255) not null
);

CREATE TABLE Contatti_Bibliotecario (
	Telefono char (10) not null,
	Email varchar (255) not null,
	ID_Tesserino char (6) not null,
	constraint FK_ID_TesserinoY foreign key (ID_Tesserino) references Bibliotecario (ID_Tesserino)
);

CREATE TABLE Presenza (
	ID_Turno char (6) primary key,
	Tipologia_Turno varchar (255),
	Data_Presenza_Ingresso timestamp,
	Data_Presenza_Uscita timestamp,
	ID_Tesserino char (6) not null,
	constraint FK_ID_TesserinoZ foreign key (ID_Tesserino) references Bibliotecario (ID_Tesserino)
);

CREATE TABLE Libro (
	ISBN char (13) primary key,
	Anno int check (Anno < 2022),
	Titolo varchar (255) not null,
	Tipologia varchar (255),
	P_IVA char (11),
	Nome_Collezione varchar (255) not null,
	constraint FK_P_IVAX foreign key (P_IVA) references Casa_Editrice (P_IVA),
	constraint FK_Nome_CollezioneX foreign key (Nome_Collezione) references Collezione (Nome_Collezione)
);

CREATE TABLE Copia (
	Num_Copia char (4) primary key,
	Stato varchar (255),
	ISBN char (13),
	Num_Tessera char (6),
	ID_Reparto int check (ID_Reparto < 500),
	constraint FK_ISBNX foreign key (ISBN) references Libro (ISBN),
	constraint FK_Num_TesseraX foreign key (Num_Tessera) references Utente (Num_Tessera),
	constraint FK_ID_RepartoX foreign key (ID_Reparto) references Reparto (ID_Reparto)
);

CREATE TABLE Richiesta (
	Cod_Richiesta char (8) primary key,
	Data_Richiesta date,
	Data_Fine_Prestito date,
	Num_Tessera char (6),
	ID_Tesserino char (6),
	constraint FK_Num_TesseraY foreign key (Num_Tessera) references Utente (Num_Tessera),
	constraint FK_ID_TesserinoX foreign key (ID_Tesserino) references Bibliotecario (ID_Tesserino)
);

CREATE TABLE Scritto_Da (
	ISBN_Libro char (13) ,
	Cod_Autore_1 char(5) not null,
	constraint Scritto_Da_PK primary key (ISBN_Libro,Cod_Autore_1),
	constraint FK_ISBN_Libro foreign key (ISBN_Libro) references Libro (ISBN),
	constraint FK_Cod_Autore_2 foreign key (Cod_Autore_1) references Autore (Cod_Autore)
);

CREATE TABLE Comprende (
	Num_Copia_1 char (4),
	Cod_Richiesta_1 char (8),
	constraint Comprende_PK primary key (Num_Copia_1,Cod_Richiesta_1),
	constraint FK_Num_Copia_1 foreign key (Num_Copia_1) references Copia (Num_Copia),
	constraint FK_Cod_Richiesta_2 foreign key (Cod_Richiesta_1) references Richiesta (Cod_Richiesta)
);