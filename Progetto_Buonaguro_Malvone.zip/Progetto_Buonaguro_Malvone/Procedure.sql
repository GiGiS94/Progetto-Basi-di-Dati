CREATE OR REPLACE PROCEDURE updatecopia (Num_Copia1 char, Stato1 varchar, ISBN1 char, Num_Tessera1 char, ID_Reparto1 int)
IS
BEGIN 
UPDATE Copia
SET Stato = Stato1
WHERE Num_Copia = Num_Copia1 AND ISBN = ISBN1 AND Num_Tessera = Num_Tessera1 AND ID_Reparto = ID_Reparto1;
dbms_output.PUT_LINE ('Copia aggiornata correttamente');
EXCEPTION      
when no_data_found then dbms_output.PUT_LINE('Errore, aggiornamento fallito');      
rollback;      
END;



CREATE OR REPLACE PROCEDURE newrichiesta (ISBN1 char, NumGiorni int, Num_Tessera1 char, ID_Tesserino1 char)
IS
Tessera_Utente char;
Tessera_Bibliotecario char;
Num_Llibro char;
Copia_Num char;
id_a int;
Giorni date;
no_tessera EXCEPTION;
no_isbn EXCEPTION;
days_not_acc EXCEPTION;
no_copia EXCEPTION;
BEGIN
SELECT Num_Tessera INTO Tessera_Utente FROM Utente WHERE Num_Tessera = Num_Tessera1;
SELECT ID_Tesserino INTO Tessera_Bibliotecario FROM Bibliotecario WHERE ID_Tesserino = ID_Tesserino1;
IF (Tessera_Utente is null AND Tessera_Bibliotecario is null) THEN RAISE no_tessera;
END IF; 
SELECT ISBN INTO Num_Llibro FROM Libro WHERE ISBN = ISBN1;
IF (ISBN1 is null) THEN RAISE no_isbn;
END IF;
SELECT Num_Copia INTO Copia_Num FROM Copia WHERE ISBN = ISBN1;
IF (TO_NUMBER (Copia_Num) <= 0) THEN RAISE no_copia;
END IF;
IF (NumGiorni <= 0) THEN RAISE days_not_acc;
END IF;
UPDATE Copia SET Num_Copia = TO_NUMBER (Copia_Num) - 1 WHERE ISBN = ISBN1;
id_a := DBMS_RANDOM.VALUE(1,99999999);
Giorni := TO_DATE(SYSDATE + NumGiorni);
INSERT INTO Richiesta (Cod_Richiesta, Data_Richiesta, Data_Fine_Prestito, Num_Tessera, ID_Tesserino) VALUES (TO_CHAR (id_a), SYSDATE, Giorni, Num_Tessera1, ID_Tesserino1);
EXCEPTION
when no_tessera then dbms_output.PUT_LINE('Errore, la tessera non corrisponde');      
rollback;
when no_isbn then dbms_output.PUT_LINE('Errore, l ISBN non esiste');      
rollback;
when days_not_acc then dbms_output.PUT_LINE('Errore, numero giorni errato');   
rollback;
when no_copia then dbms_output.PUT_LINE('Errore, non ci sono copie presenti');   
rollback;
END;



CREATE OR REPLACE PROCEDURE verifica_reparto (codice_libro char, cod_repa int)
IS
num_libro int;
stamp_repa Reparto %ROWTYPE;
BEGIN
SELECT ID_Reparto INTO num_libro
FROM Copia
WHERE num_copia = codice_libro;
IF (num_libro IS NOT NULL) THEN
SELECT * INTO stamp_repa
FROM Reparto
WHERE ID_Reparto = cod_repa;
DBMS_OUTPUT.PUT_LINE('LIBRO PRESENTE NEL REPARTO  ');
DBMS_OUTPUT.PUT_LINE( stamp_repa.ID_Reparto ' '  stamp_repa.Tipo_Reparto || ' ');
END IF;
EXCEPTION
WHEN no_data_found THEN RAISE_APPLICATION_ERROR(-20016,'LIBRO NON PRESENTE IN REPARTO');
END;



CREATE OR REPLACE PROCEDURE insertutente (num_tess char, nome_ut VARCHAR2, cognome_ut VARCHAR2, indiriz VARCHAR2, citta VARCHAR2, telef char, email VARCHAR2)
IS
BEGIN 
IF(num_tess IS NOT NULL AND nome_ut IS NOT NULL AND cognome_ut IS NOT NULL  AND indiriz IS NOT NULL AND citta IS NOT NULL AND telef IS NOT NULL AND email IS NOT NULL) THEN 
INSERT INTO Utente (Num_Tessera, Nome, Cognome, Indirizzo, Citta) VALUES (num_tess, nome_ut, cognome_ut, indiriz, citta);
INSERT INTO Contatti_Utente (Telefono, Email, Num_Tessera) VALUES (telef, email, num_tess);
dbms_output.PUT_LINE ('Utente registrato correttamente');
END IF;
EXCEPTION
when no_data_found then dbms_output.PUT_LINE('Errore, utente non inserito');
rollback;
END;